$(function() {

    var newHash      = "",
        $mainContent = $("#row"),
        $pageWrap    = $("#section"),
        baseHeight   = 0,
        $el;
        
    $pageWrap.height($pageWrap.height());
    baseHeight = $pageWrap.height() - $mainContent.height();
    
    $("col-lg-4 order-lg-1 order-2").delegate("a", "click", function() {
        window.location.hash = $(this).attr("href");
        return false;
    });
    
    $(window).bind('hashchange', function(){
    
        newHash = window.location.hash.substring(1);
        
        if (newHash) {
            $mainContent
                .find("#col-lg-8 order-lg-2 order-1")
                .fadeOut(200, function() {
                    $mainContent.hide().load(newHash + " #col-lg-8 order-lg-2 order-1", function() {
                        $mainContent.fadeIn(200, function() {
                            $pageWrap.animate({
                                height: baseHeight + $mainContent.height() + "px"
                            });
                        });
                        $("col-lg-4 order-lg-1 order-2 a").removeClass("current");
                        $("col-lg-4 order-lg-1 order-2 a[href="+newHash+"]").addClass("current");
                    });
                });
        };
        
    });
    
    $(window).trigger('hashchange');

});