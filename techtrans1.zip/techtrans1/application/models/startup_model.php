<?php
    class Startup_model extends CI_Model{
        public function __construct(){
            $this->load->database();
        }

        public function get_startup($product = FALSE){
            if($product === FALSE){
                $query = $this->db->get('startups');
                return $query->result_array();
            }
            $query = $this->db->get_where('startups', array('product' => $product));
            return $query->row_array(); 
        }

        public function create_startup(){

            $data = array(
                'co_name' => $this->input->post('co_name'),
                'product' => $this->input->post('product'),
                'category' => $this->input->post('category'),
                'expertise' => $this->input->post('expertise'),
                'date_joined' => $this->input->post('date_joined'),
                'website' => $this->input->post('website'),
                'about' => $this->input->post('about')
                
            );

            return $this->db->insert('startups', $data);
        }
    }