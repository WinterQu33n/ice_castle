<!DOCTYPE html>
<html lang="zxx">

<head>
  <meta charset="utf-8">
  <title>InstiTech</title>

  
  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  
  <!-- Bootstrap -->
  <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
  <!-- magnific popup -->
  <link rel="stylesheet" href="plugins/magnific-popup/magnific-popup.css">
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="plugins/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick/slick-theme.css">
  <!-- themify icon -->
  <link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
  <!-- animate -->
  <link rel="stylesheet" href="plugins/animate/animate.css">
  <!-- Aos -->
  <link rel="stylesheet" href="plugins/aos/aos.css">
  <!-- Stylesheets -->
  <link href="css/style.css" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
  <link rel="icon" href="images/favicon.png" type="image/x-icon">

</head>

<body>
  

<!-- preloader start -->
<div class="preloader">
    <img src="images/preloader.gif" alt="preloader">
</div>
<!-- preloader end -->

<!-- navigation -->
<header>
    <!-- top header -->
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline text-lg-right text-center">
                        <li class="list-inline-item">
                            <a href="mailto:sales@hit.ac.zw">sales@hit.ac.zw</a>
                        </li>
                        <li class="list-inline-item">
                            <a href="callto:00263242711181">Call Us Now:
                                <span class="ml-2"> +263 242 711 181</span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" id="searchOpen">
                                <i class="ti-search"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- nav bar -->
    <div class="navigation">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="index.html">
                    <img src="images/logo.png" alt="logo">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
    
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.html">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                About Us
                            </a>
                            <div class="dropdown-menu" >
                                <a class="dropdown-item" href="about.html">About TTLCC</a>
                                <a class="dropdown-item" href="infographic.html">The TTLCC Path</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="ip.html">Intellectual Property</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                InstiTech
                            </a>
                            <div class="dropdown-menu" >
                                <a class="dropdown-item" href="about-incubation.html">About</a>
                                <a class="dropdown-item" href="project.html">Incubation Hub</a>
                                <a class="dropdown-item" href="project.html">Spin-Out Companies</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="blog.html">News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.html">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-primary btn-sm" href="submit_project.php">submit your project</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>  
</header>


<!-- Search Form -->
<div class="search-form">
    <a href="#" class="close" id="searchClose">
        <i class="ti-close"></i>
    </a>
    <div class="container">
        <form action="search.php" method="POST" class="row">
            <div class="col-lg-10 mx-auto">
                <h3>Search Here</h3>
                <div class="input-wrapper">
                    <input type="text" class="form-control" name="search" id="search" placeholder="Enter Keywords..." required>
                    <button type="submit" name="submit" value="Search">
                        <i class="ti-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- /navigation --> 

<section class="page-title overlay" style="background-image: url(images/background/institech-title.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-14 text-center">
                <ol class="breadcrumb">
                    <li>
                        <a href="index.html">Home</a>
                    </li>
                    <li>InstiTech</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- service single -->
<section class="section">
    <div class="container">
        <div class="row">
            <!-- sidebar -->
            <!-- service single content -->
            <div class="col-lg-14 order-lg-2 order-1">
                <h3 class="mb-10">Intellectual Property</h3>
                <img class="img-fluid mb-60 rounded-top" src="images/service/service-single.jpg" alt="service">
                <h3 class="mb-10">Intellectual Property</h3>
                <p class="mb-40">Intellectual property (IP) is a cluster of legally recognised rights associated with innovation and creativity – the works of the mind, as opposed to physical products, land and other tangible resources. Application and registration of intellectual property can be done at <a href="http://www.aripo.org">Aripo</a> (for registration of a regionally recognised IP) or <a href="http://www.dcip.gov.zw"> The Department of Deeds</a> (for a locally recognised IP). If you work with us, we will help you in the process of knowing which IP is best for your invention and how to register it.
                    </br></br>
                    TTLCC is composed of specialists in licensing, business development and legal matters, all of whom are widely experienced in transferring technologies across a broad array of fields, including the physical sciences, life sciences and information technology. The center is responsible for managing inventions from HIT and its related centres of excellence and act as agent for the licensing of inventions from the public including its alumni.
                    </br></br>
                    We encourage you to contact the Technology Licensing Office during your discovery process to ensure you are aware of the options that will best leverage the commercial potential of your research. 
                </p>
                
                <h4 class="mb-30">What are the typical steps in the process?</h4>
                <p class="mb-40">The process of technology transfer is summarized in the steps that follow. Note that these steps can vary in sequence and often occur simultaneously.</p>
                <div class="mb-md-50">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div>
                                <ul class="d-inline-block pl-0 float-sm-left mr-sm-4">
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>A. RESEARCH:</b><p class=""></p>Observations and experiments during research activities often lead to discoveries and inventions. An invention is any useful process, machine, composition of matter, or any new or useful improvement of the same. Often, multiple researchers may have contributed to the invention.</p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>B. PRE-DISCLOSURE:</b><p class=""></p> An early contact with the Technology Licensing Office to discuss your invention and to provide guidance with respect to the disclosure, evaluation, and protection processes described below.</p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>C. DISCLOSURE (ALSO REFERRED TO AS A TECHNOLOGY DISCLOSURE): </b><p class=""></p>The written notice of invention to the Technology Licensing Office that begins the formal technology transfer process. An invention disclosure remains a confidential document, and should fully document your invention so that the options for commercialization can be evaluated and pursued. </p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>D. ASSESSMENT: </b><p class=""></p>The period in which your Technology Licensing Officer reviews (with your input) the invention disclosure, conducts patent searches (if applicable), and analyses the market and competitive technologies to determine the invention’s commercialization potential. </p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>E. PROTECTION:</b> <p class=""></p>The process in which protection for an invention is pursued to encourage third party interest in commercialization. Patent protection, a common legal protection method, begins with the filing of a patent application with the Zimbabwe  </p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>F. LICENSING: </b><p class=""></p>A license agreement is used with both a new start-up business and an established company. An option agreement is sometimes used to enable a third party to evaluate the technology and its market potential for a limited time before licensing.</p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>G. COMMERCIALIZATION: </b><p class=""></p>The licensee company continues the advancement of the technology and makes other business investments to develop the product or service. This step may entail further development, regulatory approvals, sales and marketing, support, training, and other activities.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
              
            </div>
        </div>
    </div>
</section>
<!-- /service single -->

<!-- footer -->
<footer class="bg-secondary">
    <div class="py-100 border-bottom" style="border-color: #454547 !important">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="mb-5 mb-md-0 text-center text-md-left">
                        <p class="text-white mb-30">Follow us on the following social media platforms</p>
                        <!-- social icon -->
                        <ul class="list-inline">
                            <li class="list-inline-item">
                                <a class="social-icon-outline" href="#">
                                    <i class="ti-facebook"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a class="social-icon-outline" href="#">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- footer links -->
                <div class="col-lg-2 col-md-4 col-6">
                <a href="faqs.html"><h4 class="text-white mb-4" align="right">Frequently Asked Questions</h4></a>
                
                </div>
                <!-- footer links -->
                <div class="col-lg-2 col-md-2 col-3">
                <h4 class="text-white mb-4">  </h4>
                
                </div>
                <!-- subscribe form -->
                <div class="col-lg-3 col-md-12 offset-lg-1">
                    <div class="mt-5 mt-lg-0 text-center text-md-left">
                        <h4 class="mb-4 text-white">Subscribe to us</h4>
                        <p class="text-white mb-4">Sign up to our monthly newsletter to receive the latest news and updates </p>
                        <form action="subscribe.php" method='POST' class="position-relative">
                            <input type="text" class="form-control subscribe" name="subscribe" id="subscribe" placeholder="Enter Your Email">
                            <button class="btn-subscribe" type="submit" value="send">
                                <i class="ti-arrow-right"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- copyright -->
    <div class="pt-4 pb-3 position-relative">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-5">
                    <p class="text-white text-center text-md-left">
                        <span class="text-primary">Harare Institute of Technology - TTLCC</span> &copy; 2018 All Rights Reserved</p>
                </div>
                <div class="col-lg-6 col-md-7">
                    <ul class="list-inline text-center text-md-right">
                        <li class="list-inline-item mx-lg-3 my-lg-0 mx-2 my-2">
                            <a class="font-secondary text-white" href="privacy_policy.html">Privacy Policy</a>
                        </li>
                        <li class="list-inline-item ml-lg-3 my-lg-0 ml-2 my-2 ml-0">
                            <a class="font-secondary text-white" href="terms.html">Terms &amp; Conditions</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- back to top -->
        <button class="back-to-top">
            <i class="ti-angle-up"></i>
        </button>
    </div>
</footer>
<!-- /footer --> 

<!-- jQuery -->
<script src="plugins/jQuery/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<!-- magnific popup -->
<script src="plugins/magnific-popup/jquery.magnific.popup.min.js"></script>
<!-- slick slider -->
<script src="plugins/slick/slick.min.js"></script>
<!-- mixitup filter -->
<script src="plugins/mixitup/mixitup.min.js"></script>
<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBI14J_PNWVd-m0gnUBkjmhoQyNyd7nllA"></script>
<script  src="plugins/google-map/gmap.js"></script>
<!-- Syo Timer -->
<script src="plugins/syotimer/jquery.syotimer.js"></script>
<!-- aos -->
<script src="plugins/aos/aos.js"></script>
<!-- Main Script -->
<script src="js/script.js"></script>
<!--Page Loader Script-->
<script type='text/javascript' src='js/jquery.ba-hashchange.min.js'></script>
<script type='text/javascript' src='js/dynamicpage.js'></script>
</body>
</html>