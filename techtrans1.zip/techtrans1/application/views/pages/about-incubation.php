<!DOCTYPE html>

<?php echo file_get_contents("header.html"); ?>


<section class="page-title overlay" style="background-image: url(images/background/incubation-title.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="text-white font-weight-bold">Incubation Hub</h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="index.html">Home</a>
                    </li>
                    <li>Incubation Hub</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- service single -->
<section class="section">
    <div class="container">
            <div class="row">
            <aside class="col-lg-4 order-lg-1 order-2">
            <!-- Consultation -->
            <div class="mb-50" id="mail">
                    <h5 class="mb-20">Contact us</h5>
                    <form action="contact.php" class="row">
                        <div class="col-lg-12">
                            <input type="text" class="form-control" name="name" id="name" placeholder="Name" required>
                        </div>
                        <div class="col-lg-12">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email Address"
                                required>
                        </div>
                        <div class="col-lg-12">
                            <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject"
                                required>
                        </div>
                        <div class="col-lg-12">
                            <textarea name="question" id="question" class="form-control p-2" placeholder="Your Question Here..."
                                style="height: 150px;"></textarea>
                        </div>
                        <div class="col-lg-12">
                            <button class="btn btn-primary" type="submit" value="send">Submit</button>
                        </div>
                    </form>
                </div>
            </aside>
            <!-- service single content -->
            <div class="col-lg-8 order-lg-2 order-1">
                <img class="img-fluid mb-60 rounded-top" src="images/service/incubation1.jpg" alt="service">
                <h3 class="mb-10">What is an incubation hub</h3>
                <p class="mb-40">A business incubation hub is a catalyst tool that helps startup companies to develop by providing services such as management training or office space. TTCLC incubation hub provides this and more serives. We help startups with professionals for accounting, intellectual property and legal expertise on a part-time basis. We also provide common secretarial pool/staff, intern support: Also, to provide support in management, incubates will be assigned a student from the School of Business Management Sciences, if desired.</p>

                <h3 class="mb-10">What we require if you want to join</h3>
                <p class="mb-40">If you have an idea that you think can be commercialised, you can send us a business plan of your product or invention and a prototype if you have one. </p>

                <div class="bg-gray p-5 rounded mb-60">
                    <h5 class= mb-30>What to expect at TTLCC business incubation hub</h5>
                    <div>
                        <ul class="d-inline-block pl-0 float-sm-left mr-sm-5">
                            <li class="font-secondary mb-10">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Mentoring and Advisory Services</li>
                            <li class="font-secondary mb-10">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Periodic assessment</li>
                            <li class="font-secondary mb-10">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Non-Disclosure</li>
                       
                        </ul>
                        <ul class="d-inline-block pl-0">
                            <li class="font-secondary mb-10">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Mandatory Mentorship</li>
                            <li class="font-secondary mb-10">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Tenure of Incubation</li>
                        </ul>
                    </div>
                </div>
                <h4 class="mb-30">Mentoring and Advisory Services</h4>
                <ul class="d-inline-block pl-0 float-sm-left mr-sm-5">
                        <li class="font-secondary mb-10">
                            <i class="text-primary mr-2 ti-arrow-circle-right"></i>Strategic Checkups: The TTCLC Director will meet with company CEOs at least once per month for strategy reviews and discussion of operational issues.</li>
                        <li class="font-secondary mb-10">
                            <i class="text-primary mr-2 ti-arrow-circle-right"></i>An incubate company will be provided with has a faculty advisor as a mentor on technology issues.</li>
                        <li class="font-secondary mb-10">
                            <i class="text-primary mr-2 ti-arrow-circle-right"></i>Specialized mentors are also available to the companies to assist with particular strategic areas or to provide project-oriented consultation. These arrangements may begin as a pro bono arrangement with an option for both parties to graduate to a paid relationship.</li>
                        <li class="font-secondary mb-10">
                            <i class="text-primary mr-2 ti-arrow-circle-right"></i>An incubate company may avail of consulting services by empaneled professionals of TTCLC.</li>
                </ul>

                <h4 class="mb-30">Mandatory Mentorship</h4>
                    <p class="font-secondary mb-10">The incubate has to offer minimum 1% of share equity to the mentor as a consideration of mentorship.Industry Mentor: TTCLC has created a database of Industry mentors. Every incubate company incubated at TTCLC may select one Industry mentor within six months from the date of joining incubation centre. In case the incubate opts for an industry mentor the incubate company has to offer minimum 1% of equity to the mentor as a consideration of mentorship.
                    </p>
                <h4 class="mb-30">Tenure of Incubation</h4>
                    <p class="font-secondary mb-10">Companies will be permitted to stay in the incubator for a period of two years. Maximum two extensions may be granted for 6 months each at a time at the sole discretion of the Institute.
                    </p>
                <h4 class="mb-30">Periodic assessment</h4>
                    <p class="font-secondary mb-10">The incubate company will have to submit a yearly audited statement of profit and loss account and unaudited quarterly statement about the activities. However, incubate may be asked to provide more frequent updates to TTCLC.
                    </p>
                <h4 class="mb-30">Non-Disclosure</h4>
                    <p class="font-secondary mb-10">TTCLC along with all the participants and partners will sign "non-disclosure" agreements. Furthermore, MoUs will be signed between companies/potential incubates and HIT, with TTCLC facilitating the process.
                    </p>
            </div>
        </div>
    </div>
</section>
<!-- /service single -->


<!-- footer -->
<footer class="bg-secondary">
    <div class="py-100 border-bottom" style="border-color: #454547 !important">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="mb-5 mb-md-0 text-center text-md-left">
                        <!-- logo -->
                        <img class="mb-30" src="#" alt="logo">
                        <p class="text-white mb-30">Follow us on the following social media platforms</p>
                        <!-- social icon -->
                        <ul class="list-inline">
                            <li class="list-inline-item">
                                <a class="social-icon-outline" href="#">
                                    <i class="ti-facebook"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a class="social-icon-outline" href="#">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- footer links -->
                <div class="col-lg-2 col-md-4 col-6">
                <h4 class="text-white mb-4" align="right">Quick Links</h4>
                <ul class="footer-links">
                    <li>
                        <a href="#">Company History</a>
                    </li>
                    <li>
                        <a href="#">IP Policy</a>
                    </li>
                </ul>
                </div>
                <!-- footer links -->
                <div class="col-lg-2 col-md-2 col-3">
                <h4 class="text-white mb-4"> . </h4>
                <ul class="footer-links">
                    <li>
                        <a href="faqs.html">Frequently Asked Questions</a>
                    </li>
                    <li>
                        <a href="about.html">About Us</a>
                    </li>
                </ul>
                </div>
                <!-- subscribe form -->
                <div class="col-lg-3 col-md-12 offset-lg-1">
                    <div class="mt-5 mt-lg-0 text-center text-md-left">
                        <h4 class="mb-4 text-white">Subscribe to us</h4>
                        <p class="text-white mb-4">Sign up to our monthly newsletter to receive the latest news and updates </p>
                        <form action="subscribe.php" method='POST' class="position-relative">
                            <input type="text" class="form-control subscribe" name="subscribe" id="subscribe" placeholder="Enter Your Email">
                            <button class="btn-subscribe" type="submit" value="send">
                                <i class="ti-arrow-right"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- copyright -->
    <div class="pt-4 pb-3 position-relative">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-5">
                    <p class="text-white text-center text-md-left">
                        <span class="text-primary">Harare Institute of Technology - TTLCC</span> &copy; 2018 All Rights Reserved</p>
                </div>
                <div class="col-lg-6 col-md-7">
                    <ul class="list-inline text-center text-md-right">
                        <li class="list-inline-item mx-lg-3 my-lg-0 mx-2 my-2">
                            <a class="font-secondary text-white" href="privacy_policy.html">Privacy Policy</a>
                        </li>
                        <li class="list-inline-item ml-lg-3 my-lg-0 ml-2 my-2 ml-0">
                            <a class="font-secondary text-white" href="terms.html">Terms &amp; Conditions</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- back to top -->
        <button class="back-to-top">
            <i class="ti-angle-up"></i>
        </button>
    </div>
</footer>
<!-- /footer --> 

<!-- jQuery -->
<script src="plugins/jQuery/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<!-- magnific popup -->
<script src="plugins/magnific-popup/jquery.magnific.popup.min.js"></script>
<!-- slick slider -->
<script src="plugins/slick/slick.min.js"></script>
<!-- mixitup filter -->
<script src="plugins/mixitup/mixitup.min.js"></script>
<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBI14J_PNWVd-m0gnUBkjmhoQyNyd7nllA"></script>
<script  src="plugins/google-map/gmap.js"></script>
<!-- Syo Timer -->
<script src="plugins/syotimer/jquery.syotimer.js"></script>
<!-- aos -->
<script src="plugins/aos/aos.js"></script>
<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>