
<!DOCTYPE html>

<section>
    <div class="hero-slider position-relative">
        <div class="hero-slider-item py-160" style="background-image: url(assets/images/banner/banner-1.jpg);" data-icon="ti-money" data-text="Commercialisation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hero-content">
                            <h4 class="text-uppercase mb-1" data-duration-in=".5" data-animation-in="fadeInLeft" data-delay-in=".1">We are</h4>
                            <h2 class="font-weight-bold mb-3" data-duration-in=".5" data-animation-in="fadeInLeft" data-delay-in=".5">Technology Transfer Licensing &amp; Commercialisation Center</h1>
                            <h5 data-duration-in=".5" data-animation-in="fadeInLeft" data-delay-in=".9">The Centre is responsible for technology transfer in terms  of  commercialisation  of  inventions  and  discoveries
                            </p>
                            <a data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in="1.3" href="about" class="btn btn-outline text-uppercase">more details</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-slider-item py-160" style="background-image: url(assets/images/banner/idea.jpg);" data-icon="ti-light-bulb" data-text="Innovation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hero-content">
                            <h4 class="text-uppercase mb-1" data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in=".1" >With us</h4>
                            <h1 class="font-weight-bold mb-2" data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in=".5">Your idea can change the world</h1>
                            <h5 data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in=".9">Find out how TTLCC can help you turn an idea into a business
                            </p>
                            <a data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in="1.3" href="about-incubation" class="btn btn-outline text-uppercase">more details</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-slider-item py-160" style="background-image: url(assets/images/banner/projects1.jpg);" data-icon="ti-vector" data-text="Technology">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hero-content">
                            <h1 class="font-weight-bold mb-3" data-duration-in=".5" data-animation-in="fadeInLeft" data-delay-in=".5">Our Projects</h1>
                            <h5 data-duration-in=".5" data-animation-in="fadeInLeft" data-delay-in=".9">Browse and filter through the technologies we helped to create
                            </p>
                            <a data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in="1.3" href="project" class="btn btn-outline text-uppercase">more details</a>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <div class="hero-slider-item py-160" style="background-image: url(assets/images/banner/spinout1.jpg);" data-icon="ti-bar-chart" data-text="Growth">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hero-content">
                            <h1 class="font-weight-bold mb-3" data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in=".5">TTLCC Spin out companies</h1>
                            <h5 data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in=".9">Self-sustaining businesses, built on innovative technologies,
                                <br> our spin-out companies are creating the future
                            </p>
                            <a data-duration-in=".5" data-animation-in="fadeInDown" data-delay-in="1.3" href="spin-out" class="btn btn-outline text-uppercase">more details</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- service -->
<section class="section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 text-center">
                <h5 class="section-title-sm">Best Service</h5>
                <h2 class="section-title section-title-border">Services We Provide</h2>
            </div>
            <!-- service item -->
            <div class="col-lg-4 col-sm-6 mb-5 mb-lg-0">
                <div class="card text-center">
                    <h4 class="card-title pt-3">Business Incubation</h4>
                    <div class="card-img-wrapper">
                        <img class="card-img-top rounded-0" src="assets/images/service/incubation.jpg" alt="incubation-hub-image">
                    </div>
                    <div class="card-body p-0">
                        <i class="square-icon translateY-33 rounded ti-anchor"></i>
                        <p class="card-text mx-2 mb-0">We provide start up companies with the tools they need to build their business at our business incubation hub. </p>
                        <a href="about-incubation" class="btn btn-secondary translateY-25">Read More</a>
                    </div>
                </div>
            </div>
            <!-- service item -->
            <div class="col-lg-4 col-sm-6 mb-5 mb-lg-0">
                <div class="card text-center">
                    <h4 class="card-title pt-3">IP Protection Management</h4>
                    <div class="card-img-wrapper">
                        <img class="card-img-top rounded-0" src="assets/images/service/ip.jpg" alt="service-image">
                    </div>
                    <div class="card-body p-0">
                        <i class="square-icon translateY-33 rounded ti-lock"></i>
                        <p class="card-text mx-2 mb-0">We provide intellectual property advice and consultation services as well as intellectual property management</p>
                        <a href="ip" class="btn btn-secondary translateY-25">Read More</a>
                    </div>
                </div>
            </div>
            <!-- service item -->
            <div class="col-lg-4 col-sm-6">
                <div class="card text-center">
                    <h4 class="card-title pt-3">Corporate Partnering</h4>
                    <div class="card-img-wrapper">
                        <img class="card-img-top rounded-0" src="assets/images/service/partnership.jpg" alt="service-image">
                    </div>
                    <div class="card-body p-0">
                        <i class="square-icon translateY-33 rounded ti-briefcase"></i>
                        <p class="card-text mx-2 mb-0">Partnering with other companies to provide technical skills needed in developing specialty projects</p>
                        <a href="service-single.html" class="btn btn-secondary translateY-25">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="about section-sm overlay" style="background-image: url(assets/images/background/about-us.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 ml-auto">
                <div class="rounded p-sm-5 px-3 py-5 bg-secondary">
                    <h3 class="section-title section-title-border-half text-white">Who We Are</h3>
                    <p class="text-white mb-40">We are the hub for venture mentoring services and establishment of a cross functional technopreneurship forum.</p>
                    <div>
                        <ul class="d-inline-block pl-0">
                            <li class="font-secondary mb-10 text-white float-sm-left mr-sm-5">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Entrepreneurial development &amp; support</li>
                            <li class="font-secondary mb-10 text-white">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Intellectual Property (IP) protection and management</li>
                            <li class="font-secondary mb-10 text-white">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>IP advice support</li>
                        </ul>
                        <ul class="d-inline-block pl-0">
                            <li class="font-secondary mb-10 text-white">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Research commercialisation</li>
                            <li class="font-secondary mb-10 text-white">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Creation of spin-out companies</li>
                            <li class="font-secondary mb-10 text-white">
                                <i class="text-primary mr-2 ti-arrow-circle-right"></i>Management of Institute’s Innovation Fund</li>
                        </ul>
                    </div>
                    <a href="about" class="btn btn-primary mt-4">Explore More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- skill -->
<section class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="section-title section-title-border-half">Understanding Commercialisation</h2>
            </div>
            <div class="col-lg-7">
                <div class="mb-40">
                    <p class="text-dark">Commercialization is the process by which a new product or service is introduced into the general market.</p>
                    <p class="text-dark mb-30">The process of commercialization is broken into phases, from the initial introduction of the product through its mass production and adoption the concept can also be simply defined as the process of introducing a new product or production method into commerce—making it available on the market. Commercial potential is the opportunity of commercialization of the candidate technology. Every new technology to reach market needs to thrive and prosper in a continuously changing and unpredictable business environment.</p>
                </div>
                <!-- fun-fact -->
                <div class="mb-md-50">
                    <div class="row">
                        <div class="col-4">
                            <div class="d-flex flex-column flex-sm-row align-items-center">
                                <i class="round-icon mr-sm-3 ti-server"></i>
                                <div class="text-center text-sm-left">
                                    <h2 class="count mb-0" data-count="8">0</h2>
                                    <p class="mb-0">Company registered</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="d-flex flex-column flex-sm-row align-items-center">
                                <i class="round-icon mr-sm-3 ti-face-smile"></i>
                                <div class="text-center text-sm-left">
                                    <h2 class="count mb-0" data-count="12">0</h2>
                                    <p class="mb-0">Projects done</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="d-flex flex-column flex-sm-row align-items-center">
                                <i class="round-icon mr-sm-3 ti-thumb-up"></i>
                                <div class="text-center text-sm-left">
                                    <h2 class="count mb-0" data-count="15">0</h2>
                                    <p class="mb-0">Products created</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- progressbar -->
            <div class="col-lg-4 offset-lg-1">
                <div class="progressbar">
                    <h5 class="progressbar-title">Branding</h5>
                    <div class="progress" data-percent="85%">
                        <div class="progress-bar progress-bar-striped" style="width: 85%;">
                            <div class="progress-bar-value">85%</div>
                        </div>
                    </div>
                </div>
                <div class="progressbar">
                    <h5 class="progressbar-title">Consulting</h5>
                    <div class="progress" data-percent="90%">
                        <div class="progress-bar progress-bar-striped" style="width: 90%;">
                            <div class="progress-bar-value">90%</div>
                        </div>
                    </div>
                </div>
                <div class="progressbar">
                    <h5 class="progressbar-title">Business</h5>
                    <div class="progress" data-percent="75%">
                        <div class="progress-bar progress-bar-striped" style="width: 75%;">
                            <div class="progress-bar-value">75%</div>
                        </div>
                    </div>
                </div>
                <div class="progressbar">
                    <h5 class="progressbar-title">Promotion</h5>
                    <div class="progress" data-percent="90%">
                        <div class="progress-bar progress-bar-striped" style="width: 90%;">
                            <div class="progress-bar-value">90%</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /skill -->

<!-- work -->
<section class="section bg-gray">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h5 class="section-title-sm">Our Works</h5>
                <h2 class="section-title section-title-border-gray">Latest Projects</h2>
            </div>
        </div>
        <!-- work slider -->
        <div class="row work-slider">
            <div class="col-lg-3 px-0">
                <div class="work-slider-image">
                    <img class="img-fluid w-100" src="assets/images/project/project-1.jpg" alt="work-image">
                    <div class="image-overlay">
                        <a class="popup-image" data-effect="mfp-zoom-in" href="assets/images/project/project-1.jpg">
                            <i class="ti-search"></i>
                        </a>
                        <a class="h4" href="nhaka.html">Nhaka E-Learning</a>
                        <p>by Nhaka </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 px-0">
                <div class="work-slider-image">
                    <img class="img-fluid w-100" src="assets/images/project/project-5.jpg" alt="work-image">
                    <div class="image-overlay">
                        <a class="popup-image" data-effect="mfp-zoom-in" href="assets/images/project/project-5.jpg">
                            <i class="ti-search"></i>
                        </a>
                        <a class="h4" href="powerfirm.html">Transformer Technlogies</a>
                        <p>by Powerfirm Engineering</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 px-0">
                <div class="work-slider-image">
                    <img class="img-fluid w-100" src="assets/images/works/lads.jpg" alt="work-image">
                    <div class="image-overlay">
                        <a class="popup-image" data-effect="mfp-zoom-in" href="assets/images/works/lads.jpg">
                            <i class="ti-search"></i>
                        </a>
                        <a class="h4" href="tetisol.html">LADS</a>
                        <p>by Tetisol</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 px-0">
                <div class="work-slider-image">
                    <img class="img-fluid w-100" src="assets/images/works/nhume.jpg" alt="work-image">
                    <div class="image-overlay">
                        <a class="popup-image" data-effect="mfp-zoom-in" href="assets/images/works/nhume.jpg">
                            <i class="ti-search"></i>
                        </a>
                        <a class="h4" href="tetisol.html">Nhume</a>
                        <p>by Tetisol</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 px-0">
                <div class="work-slider-image">
                    <img class="img-fluid w-100" src="assets/images/project/project-2.jpg" alt="work-image">
                    <div class="image-overlay">
                        <a class="popup-image" data-effect="mfp-zoom-in" href="assets/images/project/project-2.jpg">
                            <i class="ti-search"></i>
                        </a>
                        <a class="h4" href="nececity.html">Nececity</a>
                        <p>by Nececity</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 px-0">
                <div class="work-slider-image">
                    <img class="img-fluid w-100" src="assets/images/works/onetrade.jpg" alt="work-image">
                    <div class="image-overlay">
                        <a class="popup-image" data-effect="mfp-zoom-in" href="assets/images/works/onetrade.jpg">
                            <i class="ti-search"></i>
                        </a>
                        <a class="h4" href="kamifa.html">Onetrade</a>
                        <p>by Kamifa</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 px-0">
                <div class="work-slider-image">
                    <img class="img-fluid w-100" src="assets/images/project/project-6.jpg" alt="work-image">
                    <div class="image-overlay">
                        <a class="popup-image" data-effect="mfp-zoom-in" href="assets/images/project/project-6.jpg">
                            <i class="ti-search"></i>
                        </a>
                        <a class="h4" href="netro.html">Netro</a>
                        <p>by Netro Electronics</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /work -->

<!-- mission -->

<!-- /mission -->

<!-- promo-video -->

<!-- /promo-video -->


<section class="cta overlay-primary py-50 text-center text-lg-left" style="background-image: url(images/background/cta.jpg);">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-6">
                    <h3 class="text-white">Start working with us today</h3>
                </div>
                <div class="col-lg-6 text-lg-right align-self-center">
                    <a href="contact" class="btn btn-light">Contact Us</a>
                </div>
            </div>
        </div>
</section>

<!-- blog -->


<!-- client logo slider -->
<section class="bg-white py-4">
    <div class="container">
        <div class="client-logo-slider align-self-center">
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-1.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-2.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-3.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-4.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-5.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-6.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-7.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-8.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-9.png"
                    alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-10.png"
                    alt="client-logo"></a>
        </div>
    </div>
</section>
<!-- /client logo slider -->

