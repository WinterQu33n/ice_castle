<!DOCTYPE html>

<section class="page-title overlay" style="background-image: url(assets/images/about/page_banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
               
                <ol class="breadcrumb">
                    <li>
                        <a href="home">Home</a>
                    </li>
                    <li>About Us</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- philosophy -->
<section class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 order-2 order-lg-1">
                <h5 class="section-title-sm">Know About</h5>
                <h2 class="section-title section-title-border-half">Who we are</h2>
                <p>Technology Transfer, Licensing & Commercialisation Centre (TTLCC) is responsible for the management of the Institute’s Research, Development and Innovation outputs. The Centre is responsible for technology transfer in terms of commercialization of inventions and discoveries, Tech-Licensing and business ventures including, but not limited to, joint venture partnerships, venture capital etc.  </p>
                <p>TTLCC is the hub for venture mentoring services and establishment of a cross functional technopreneurship forum. The main role of the TTLCC is to manage the Harare Institute of Technology’s Intellectual Property (HIT IP) & Innovation Policy.</p>
            </div>
            <!-- philosophy image -->
            <div class="col-lg-5 align-self-center order-1 order-lg-2 mb-md-50">
                <img class="img-fluid w-100" src="assets/images/about/philosophy.jpg" alt="philosophy-image">
            </div>
        </div>
    </div>
</section>
<!-- /philosophy -->

<!-- ceo section -->
<section>
    <div class="container">
        <div class="row rounded bg-secondary">
            <!-- ceo image -->
            <div class="col-lg-5 rounded-left ceo-image" style="background-image: url(assets/images/about/talon.jpg);"></div>
            <div class="col-lg-7">
                <!-- ceo content -->
                <div class="p-5">
                    <h2 class="section-title section-title-border-half-white text-white">We are here to
                        <br> make your idea a reality </h2>
                    <p class="text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit sed eiusmod tempor didunt laboris nisi ut aliquip
                        ex commodo consequat. duis aute irure dolor in reprehenderit voluptate velit esse cillum dolore fugiat
                        nulla pariatur.Excepteur sint ocaecat cupidatat non proident sunt culpa qui officia deserunt mollit
                        anim id est laborum.</p>
                    <img src="assets/images/about/signature1.png" alt="ceo-signature">
                    <h5 class="text-white">Dr. (Eng) Talon Garikayi</h5>
                    <h6 class="text-white">Director</h6>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /ceo section -->

<!-- skill -->
<section class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h5 class="section-title-sm">Best Reason</h5>
                <h2 class="section-title section-title-border-half">Why Choose Us</h2>
            </div>
            <!-- accordion -->
            <div class="col-lg-6">
                <div id="accordion" class="mb-md-50">
                    <div class="card border-0 mb-4">
                        <div class="card-header bg-gray border p-0">
                            <a class="card-link h5 d-block tex-dark mb-0 py-10 px-4" data-toggle="collapse" href="#collapseOne">
                                <i class="ti-minus text-primary mr-2"></i> Our Company Mission
                            </a>
                        </div>
                        <div id="collapseOne" class="collapse show" data-parent="#accordion">
                            <div class="card-body font-secondary text-color pl-0 pb-0">
                                To commercialise and unlock value in the institute’s research outputs
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 mb-4">
                        <div class="card-header bg-gray border p-0">
                            <a class="collapsed card-link h5 d-block tex-dark mb-0 py-10 px-4" data-toggle="collapse" href="#collapseTwo">
                                <i class="ti-plus text-primary mr-2"></i> Destiny
                            </a>
                        </div>
                        <div id="collapseTwo" class="collapse" data-parent="#accordion">
                            <div class="card-body font-secondary text-color pl-0 pb-0">
                                To be the leading research-to-business platform through value addition to research outputs process of the research outputs.
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 mb-4">
                        <div class="card-header bg-gray border p-0">
                            <a class="collapsed card-link h5 d-block tex-dark mb-0 py-10 px-4" data-toggle="collapse" href="#collapseThree">
                                <i class="ti-plus text-primary mr-2"></i> Cause
                            </a>
                        </div>
                        <div id="collapseThree" class="collapse" data-parent="#accordion">
                            <div class="card-body font-secondary text-color pl-0 pb-0">
                                To cultivate technopreneurial researchers through market opportunities, intellectual property protection and partnering/licensing arrangements.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- progressbar -->
            <div class="col-lg-6">
                <div class="progressbar">
                    <h5 class="progressbar-title">ICT</h5>
                    <div class="progress" data-percent="85%">
                        <div class="progress-bar progress-bar-striped" style="width: 90%;">
                            <div class="progress-bar-value">90%</div>
                        </div>
                    </div>
                </div>
                <div class="progressbar">
                    <h5 class="progressbar-title">Engineering</h5>
                    <div class="progress" data-percent="75%">
                        <div class="progress-bar progress-bar-striped" style="width: 75%;">
                            <div class="progress-bar-value">75%</div>
                        </div>
                    </div>
                </div>
                <div class="progressbar">
                    <h5 class="progressbar-title">Research</h5>
                    <div class="progress" data-percent="90%">
                        <div class="progress-bar progress-bar-striped" style="width: 80%;">
                            <div class="progress-bar-value">80%</div>
                        </div>
                    </div>
                </div>
                <div class="progressbar">
                    <h5 class="progressbar-title">Commercialisation</h5>
                    <div class="progress" data-percent="75%">
                        <div class="progress-bar progress-bar-striped" style="width: 75%;">
                            <div class="progress-bar-value">75%</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- testimonial -->
<section class="section pb-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h5 class="section-title-sm">Testimonies</h5>
                <h2 class="section-title section-title-border"> What people say </h2>
            </div>
            <div class="col-lg-5 col-md-5 pr-0 align-self-center">
                <img class="img-fluid w-100" src="assets/images/client1.png" alt="clients-image">
            </div>
            <div class="col-lg-7 col-md-7 align-self-center pl-0">
                <div class="testimonial-slider p-5">
                    <!-- slider item -->
                    <div class="outline-0">
                        <i class="testimonial-icon ti-quote-left"></i>
                        <p class="text-dark">Lorem ipsum dolor sit amet constur adipisicing elit sed eiusmtempor incid sed dolore magna aliqu enim minim veniam quis nostrud exercittion ullamco labo ris nisi aliquip excepteur.</p>
                        <h4 class="font-weight-normal">Julia Robertson</h4>
                        <h6 class="font-secondary text-color">Happy Clients</h6>
                    </div>
                    <!-- slider item -->
                    <div class="outline-0">
                        <i class="testimonial-icon ti-quote-left"></i>
                        <p class="text-dark">Lorem ipsum dolor sit amet constur adipisicing elit sed eiusmtempor incid sed dolore magna aliqu enim minim veniam quis nostrud exercittion ullamco labo ris nisi aliquip excepteur.</p>
                        <h4 class="font-weight-normal">Julia Robertson</h4>
                        <h6 class="font-secondary text-color">Happy Clients</h6>
                    </div>
                    <!-- slider item -->
                    <div class="outline-0">
                        <i class="testimonial-icon ti-quote-left"></i>
                        <p class="text-dark">Lorem ipsum dolor sit amet constur adipisicing elit sed eiusmtempor incid sed dolore magna aliqu enim minim veniam quis nostrud exercittion ullamco labo ris nisi aliquip excepteur.</p>
                        <h4 class="font-weight-normal">Julia Robertson</h4>
                        <h6 class="font-secondary text-color">Happy Clients</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /testimonial --> 

<!-- client logo slider -->
<section class="bg-gray py-4">
    <div class="container">
        <div class="client-logo-slider align-self-center">
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-1.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-2.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-3.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-4.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-5.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-1.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-2.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-3.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-4.png" alt="client-logo"></a>
            <a href="#" class="text-center d-block outline-0 py-3 px-2"><img class="d-unset" src="assets/images/client-logo/client-logo-5.png" alt="client-logo"></a>
        </div>
    </div>
</section>
<!-- /client logo slider -->

<!-- footer -->
