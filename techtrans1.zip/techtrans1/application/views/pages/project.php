<!DOCTYPE html>


<section class="page-title overlay" style="background-image: url(assets/images/background/institech-title.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="text-white font-weight-bold">Our Projects</h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="home">Home</a>
                    </li>
                    <li>Our Project</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="mb-2">Our Projects</h2>
                <p class="mb-40">A summary of the Start-ups we've worked on or are currently under our wing.
                  <br>Learn more about our incubation hub & how to join <br> <a class="nav-link btn btn-primary btn-sm" href="about-incubation">here</a>  </p>
            </div>
            <div class="col-lg-12">
                <div class="project-menu text-center">
                    <ul class="controls list-inline">
                        <!-- filter item list -->
                        <li class="list-inline-item control active" data-filter="all">All</li>
                        <li class="list-inline-item control" data-filter=".Marketing-Online">ICT Online</li>
                        <li class="list-inline-item control" data-filter=".Business-Strategy">Engineering</li>
                        <!-- <li class="list-inline-item control" data-filter=".Ecomerce-Advice">Science & Technology</li> -->
                    </ul>
                </div>
            </div>
        </div>
        <div class="row" data-ref="mixitup-container">
            <div class="col-lg-3 col-md-4 col-sm-6 p-0 Marketing-Online" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-1.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="nhaka.html" class="h4">Nhaka E-Learning</a>
                        <p>
                            <i class="ti-tag"></i>E-Learning</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 p-0 Business-Strategy" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-5.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="powerfirm.html" class="h4">Powerfirm Engineering</a>
                        <p>
                            <i class="ti-tag"></i>Transformer Engineering</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 p-0 Marketing-Online" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-3.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="kamifa.html" class="h4">Kamifa</a>
                        <p>
                            <i class="ti-tag"></i>E-Commerce</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 p-0 Marketing-Online" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-4.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="tetisol.html" class="h4">Tetisol</a>
                        <p>
                            <i class="ti-tag"></i>ICT</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6 p-0 Marketing-Online Dynamic-Development" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-2.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="nececity.html" class="h4">Nececity</a>
                        <p>
                            <i class="ti-tag"></i>Mobile Vehicle Tracking</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 p-0 Business-Strategy" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-6.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="netro.html" class="h4">Netro Electronics</a>
                        <p>
                            <i class="ti-tag"></i>Electronics</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 p-0 Business-Strategy" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-7.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="gensys.html" class="h4">Gensys Zimbabwe</a>
                        <p>
                            <i class="ti-tag"></i>Generator Engineering</p>
                    </div>
                </div>
            </div>
            <!--<div class="col-lg-3 col-md-4 col-sm-6 p-0 Business-Strategy" data-ref="mixitup-target">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="images/project/project-8.jpg" alt="project-image">
                    <div class="project-info">
                        <a href="belvedere.html" class="h4">Belvedere Engineering</a>
                        <p>
                            <i class="ti-tag"></i>Engineering</p>
                    </div>
                </div>-->
            </div>
                </div>
            </div>
        </div>
    </div>
</section>

