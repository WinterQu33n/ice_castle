<!DOCTYPE html>

<?php echo file_get_contents("header.html"); ?>

<section class="page-title overlay" style="background-image: url(images/background/page-title.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="text-white font-weight-bold">Kamifa</h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="index.html">Home</a>
                    </li>
                    <li>Kamifa</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- project single -->
<section class="section">
    <div class="container">
        <div class="row">
            <aside class="col-lg-4 order-lg-1 order-2">
                <!-- overview -->
                <div class="p-4 rounded border mb-50">
                    <h4 class="text-color mb-20">Overview</h4>
                    <ul class="pl-0 mb-20">
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Company Name:</span>Kamifa</li>
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Category:</span>ICT</li>
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Expertise:</span>E-Commerce Application</li>
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Date Joined:</span>August, 2018</li>
                    </ul>
                    <a href="https://www.kamifa.co.zw" class="btn btn-primary">Visit Website</a>
                </div>
            
            </aside>
            <!-- project content -->
            <div class="col-lg-8 order-lg-2 order-1">
                <img class="img-fluid w-100 mb-60" src="images/project/kamifa1.jpg" alt="project image">
                <h3 class="mb-10">Kamifa</h3>
                <p class="mb-40">The company developed OneTrade or <a href="http://www.onetrade.co.zw">TeleTrade</a> an online shopping site which is regarded as the African version of Alibaba or eBay. Their insights are set on providing a marketing platform for local SME companies at Siyaso in Mbare, Fabricators in Gaza-Highfields, Green Market in Mutare and Furniture Companies at Glenview complex. It will enable small companies to sell their goods online. This product was achieved in partnership with Telone and was exhibited on 29 August 2018 at the Zimbabwe Agricultural Show. The product was handed over to Telone 21 September 2018 as a finalised alpha model of the application.
                </p>
                <!-- nav tabs menu -->
            </div>
        </div>
    </div>
</section>


<?php echo file_get_contents("footer.html"); ?>