<!DOCTYPE html>

<section class="page-title overlay" style="background-image: url(images/background/intellectualproperty.png);">
    <div class="container">
        <div class="row">
            <div class="col-lg-14 text-center">
                <h2 class="text-white font-weight-bold">Intellectual Property</h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="index.html">Home</a>
                    </li>
                    <li>Intellectual Property</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- service single -->
<section class="section">
    <div class="container">
        <div class="row">
            <!-- sidebar -->
            <!-- service single content -->
            <div class="col-lg-14 order-lg-2 order-1">
                <img class="img-fluid mb-60 rounded-top" src="images/ip/patents.jpg" alt="patent">
                <h3 class="mb-10">Intellectual Property</h3>
                <p class="mb-40">Intellectual property (IP) is a cluster of legally recognised rights associated with innovation and creativity – the works of the mind, as opposed to physical products, land and other tangible resources. Application and registration of intellectual property can be done at <a href="http://www.aripo.org">Aripo</a> (for registration of a regionally recognised IP) or <a href="http://www.dcip.gov.zw"> The Department of Deeds</a> (for a locally recognised IP). If you work with us, we will help you in the process of knowing which IP is best for your invention and how to register it.
                    </br></br>
                    TTLCC is composed of specialists in licensing, business development and legal matters, all of whom are widely experienced in transferring technologies across a broad array of fields, including the physical sciences, life sciences and information technology. The center is responsible for managing inventions from HIT and its related centres of excellence and act as agent for the licensing of inventions from the public including its alumni.
                    </br></br>
                    We encourage you to contact the Technology Licensing Office during your discovery process to ensure you are aware of the options that will best leverage the commercial potential of your research. 
                </p>
                
                <h4 class="mb-30">What are the typical steps in the process?</h4>
                <p class="mb-40">The process of technology transfer is summarized in the steps that follow. Note that these steps can vary in sequence and often occur simultaneously.</p>
                <div class="mb-md-50">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div>
                                <ul class="d-inline-block pl-0 float-sm-left mr-sm-4">
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>A. RESEARCH:</b><p class=""></p>Observations and experiments during research activities often lead to discoveries and inventions. An invention is any useful process, machine, composition of matter, or any new or useful improvement of the same. Often, multiple researchers may have contributed to the invention.</p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>B. PRE-DISCLOSURE:</b><p class=""></p> An early contact with the Technology Licensing Office to discuss your invention and to provide guidance with respect to the disclosure, evaluation, and protection processes described below.</p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>C. DISCLOSURE (ALSO REFERRED TO AS A TECHNOLOGY DISCLOSURE): </b><p class=""></p>The written notice of invention to the Technology Licensing Office that begins the formal technology transfer process. An invention disclosure remains a confidential document, and should fully document your invention so that the options for commercialization can be evaluated and pursued. </p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>D. ASSESSMENT: </b><p class=""></p>The period in which your Technology Licensing Officer reviews (with your input) the invention disclosure, conducts patent searches (if applicable), and analyses the market and competitive technologies to determine the invention’s commercialization potential. </p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>E. PROTECTION:</b> <p class=""></p>The process in which protection for an invention is pursued to encourage third party interest in commercialization. Patent protection, a common legal protection method, begins with the filing of a patent application with the Zimbabwe  </p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>F. LICENSING: </b><p class=""></p>A license agreement is used with both a new start-up business and an established company. An option agreement is sometimes used to enable a third party to evaluate the technology and its market potential for a limited time before licensing.</p></li>
                                    <li class="font-secondary mb-10">
                                        <i class="text-primary mr-2 ti-arrow-circle-right"></i><b>G. COMMERCIALIZATION: </b><p class=""></p>The licensee company continues the advancement of the technology and makes other business investments to develop the product or service. This step may entail further development, regulatory approvals, sales and marketing, support, training, and other activities.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
              
            </div>
        </div>
    </div>
</section>
<!-- /service single -->

