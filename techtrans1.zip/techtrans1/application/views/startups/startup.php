
<section class="page-title overlay" style="background-image: url(images/background/page-title.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="text-white font-weight-bold"><?php echo $product['product'];?></h2>
                <ol class="breadcrumb">
                    <li>
                    <a href="<?php echo base_url(); ?>index">Home</a>
                    </li>
                    <li><?php echo $product['product'];?></li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- project single -->
<section class="section">
    <div class="container">
        <div class="row">
            <aside class="col-lg-4 order-lg-1 order-2">
                <!-- overview -->
                <div class="p-4 rounded border mb-50">
                    <h4 class="text-color mb-20">Overview</h4>
                    <ul class="pl-0 mb-20">
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Company Name:</span><?php echo $product['co_name'];?></li>
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Product:</span><?php echo $product['product'];?></li>
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Category:</span><?php echo $product['category'];?></li>
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Expertise:</span><?php echo $product['expertise'];?></li>
                        <li class="py-3 border-bottom">
                            <span class="d-inline-block" style="width: 140px;">Date Joined:</span><?php echo $product['date_joined'];?></li>
                    </ul>
                    <a href="<?php echo $product['website'];?>" class="btn btn-primary">Visit Website</a>
                </div>
            
            </aside>
            <!-- project content -->
            <div class="col-lg-8 order-lg-2 order-1">
                <img class="img-fluid w-100 mb-60" src="<?=base_url().'assets/images/project/'.$product['image_name'];?>" alt="project image">
                <h3 class="mb-10"><?php echo $product['co_name'];?></h3>
                <p class="mb-40"><?php echo $product['about'];?>
                </p>
                <!-- nav tabs menu -->
            </div>
        </div>
    </div>
</section>


