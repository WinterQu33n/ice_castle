<!-- footer -->
<footer class="bg-secondary">
    <div class="py-100 border-bottom" style="border-color: #454547 !important">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="mb-5 mb-md-0 text-center text-md-left">
                        <p class="text-white mb-30">Follow us on the following social media platforms</p>
                        <!-- social icon -->
                        <ul class="list-inline">
                            <li class="list-inline-item">
                                <a class="social-icon-outline" href="#">
                                    <i class="ti-facebook"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a class="social-icon-outline" href="#">
                                    <i class="ti-twitter-alt"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- footer links -->
                <div class="col-lg-2 col-md-4 col-6">
                <a href="<?php echo base_url(); ?>/faqs"><h4 class="text-white mb-4" align="right">Frequently Asked Questions</h4></a>
                
                </div>
                <!-- footer links -->
                <div class="col-lg-2 col-md-2 col-3">
                <h4 class="text-white mb-4">  </h4>
                
                </div>
                <!-- subscribe form -->
                <div class="col-lg-3 col-md-12 offset-lg-1">
                    <div class="mt-5 mt-lg-0 text-center text-md-left">
                        <h4 class="mb-4 text-white">Subscribe to us</h4>
                        <p class="text-white mb-4">Sign up to our monthly newsletter to receive the latest news and updates </p>
                        <form action="subscribe.php" method='POST' class="position-relative">
                            <input type="text" class="form-control subscribe" name="subscribe" id="subscribe" placeholder="Enter Your Email">
                            <button class="btn-subscribe" type="submit" value="send">
                                <i class="ti-arrow-right"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- copyright -->
    <div class="pt-4 pb-3 position-relative">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-5">
                    <p class="text-white text-center text-md-left">
                        <span class="text-primary">Harare Institute of Technology - TTLCC</span> &copy; 2018 All Rights Reserved</p>
                </div>
                <div class="col-lg-6 col-md-7">
                    <ul class="list-inline text-center text-md-right">
                        <li class="list-inline-item mx-lg-3 my-lg-0 mx-2 my-2">
                            <a class="font-secondary text-white" href="<?php echo base_url(); ?>/privacy_policy">Privacy Policy</a>
                        </li>
                        <li class="list-inline-item ml-lg-3 my-lg-0 ml-2 my-2 ml-0">
                            <a class="font-secondary text-white" href="<?php echo base_url(); ?>/terms">Terms &amp; Conditions</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- back to top -->
        <button class="back-to-top">
            <i class="ti-angle-up"></i>
        </button>
    </div>
</footer>
<!-- /footer --> 

<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/plugins/jQuery/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="<?php echo base_url(); ?>assets/plugins/bootstrap/bootstrap.min.js"></script>
<!-- magnific popup -->
<script src="<?php echo base_url(); ?>assets/plugins/magnific-popup/jquery.magnific.popup.min.js"></script>
<!-- slick slider -->
<script src="<?php echo base_url(); ?>assets/plugins/slick/slick.min.js"></script>
<!-- mixitup filter -->
<script src="<?php echo base_url(); ?>assets/plugins/mixitup/mixitup.min.js"></script>
<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBI14J_PNWVd-m0gnUBkjmhoQyNyd7nllA"></script>
<script src="<?php echo base_url(); ?>assets/plugins/google-map/gmap.js"></script>
<!-- Syo Timer -->
<script src="<?php echo base_url(); ?>assets/plugins/syotimer/jquery.syotimer.js"></script>
<!-- aos -->
<script src="<?php echo base_url(); ?>assets/plugins/aos/aos.js"></script>
<!-- Main Script -->
<script src="<?php echo base_url(); ?>assets/js/script.js"></script>

</body>
</html>