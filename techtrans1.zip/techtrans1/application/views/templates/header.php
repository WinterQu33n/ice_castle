
<html lang="zxx">

<head>
  <meta charset="utf-8">
  <title>Technlogy Transfer Licensing & Commercialisation Center</title>
  
  <!-- Bootstrap -->
  <link href="<?php echo base_url(); ?>assets/plugins/bootstrap/bootstrap.min.css"  rel="stylesheet" type= "text/css">
  <!-- magnific popup -->
  <link href="<?php echo base_url(); ?>assets/plugins/magnific-popup/magnific-popup.css"  rel="stylesheet" type= "text/css">
  <!-- Slick Carousel -->
  <link href="<?php echo base_url(); ?>assets/plugins/slick/slick.css"  rel="stylesheet" type= "text/css">
  <link href="<?php echo base_url(); ?>assets/plugins/slick/slick-theme.css"  rel="stylesheet" type= "text/css">
  <!-- themify icon -->
  <link href="<?php echo base_url(); ?>assets/plugins/themify-icons/themify-icons.css"  rel="stylesheet" type= "text/css">
  <!-- animate -->
  <link href="<?php echo base_url(); ?>assets/plugins/animate/animate.css"  rel="stylesheet" type= "text/css">
  <!-- Aos -->
  <link href="<?php echo base_url(); ?>assets/plugins/aos/aos.css"  rel="stylesheet" type= "text/css">
  <!-- Stylesheets -->
  <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet"  type= "text/css">
   <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <!--Favicon-->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/favicon.png" type="image/x-icon">
  <link rel="icon" href="<?php echo base_url(); ?>assets/images/favicon.png" type="image/x-icon">

</head>

<body>
   

<!-- preloader start -->
<div class="preloader">
    <img src="<?php echo base_url(); ?>assets/images/preloader.gif" alt="preloader">
</div>
<!-- preloader end --> 

<!-- navigation -->
<header>
    <!-- top header -->
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline text-lg-right text-center">
                        <li class="list-inline-item">
                            <a href="mailto:sales@hit.ac.zw">sales@hit.ac.zw</a>
                        </li>
                        <li class="list-inline-item">
                            <a href="callto:00263242711181">Call Us Now:
                                <span class="ml-2"> +263 242 711 181</span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" id="searchOpen">
                                <i class="ti-search"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- nav bar -->
    <div class="navigation">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="<?php echo base_url(); ?>">
                    <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="logo">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
    
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url(); ?>">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                About Us
                            </a>
                            <div class="dropdown-menu" >
                                <a class="dropdown-item" href="<?php echo base_url(); ?>about">About TTLCC</a>
                                <a class="dropdown-item" href="<?php echo base_url(); ?>infographic">The TTLCC Path</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url(); ?>/ip">Intellectual Property</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                InstiTech
                            </a>
                            <div class="dropdown-menu" >
                                <a class="dropdown-item" href="<?php echo base_url(); ?>institech">About</a>
                                <a class="dropdown-item" href="<?php echo base_url(); ?>project">Incubation Hub</a>
                                <a class="dropdown-item" href="<?php echo base_url(); ?>spinout">Spin-Out Companies</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url(); ?>posts/index">News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url(); ?>contact">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-primary btn-sm" href="<?php echo base_url(); ?>submit_project">submit your project</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>  
</header>


<!-- Search Form -->
<div class="search-form">
    <a href="#" class="close" id="searchClose">
        <i class="ti-close"></i>
    </a>
    <div class="container">
        <form action="search.php" method="POST" class="row">
            <div class="col-lg-10 mx-auto">
                <h3>Search Here</h3>
                <div class="input-wrapper">
                    <input type="text" class="form-control" name="search" id="search" placeholder="Enter Keywords..." required>
                    <button type="submit" name="submit" value="Search">
                        <i class="ti-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- /navigation --> 