<!DOCTYPE html>

<?php echo file_get_contents("header.html"); ?>

<!-- contact -->
<section class="section">
    <div class="container">
            <h5 class="mb-100">
                    This form is strictly for current and former students of the Harare Institute of Technology. If you are not a student of HIT and you wish to submit your project to us you can do so on this <a href="contact.html">page</a>.
            </h5>
        <div class="row">
            <div class="col-lg-4 offset-lg-1 col-md-5">
                <h4 class="section-title">Why you should submit your project</h4>
                <p>
                    The Technology Transfer Licensing & Commercialisation Center keeps an archive of all projects done by HIT students which it will then look through to find projects that can be commercialised. It also uses the archive to pull projects that may solve a problem presented by a company or organisation in the industry. 
                </p>
            </div>
            <!-- form -->
            <div class="col-lg-6 col-md-7">
                <div class="p-5 rounded box-shadow">
                    <form action="submit_project.php" class="row">
                        <div class="col-lg-12">
                            <h4>Submission Your Project Documentation</h4>
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="student_id" id="student_id" class="form-control" placeholder="Student ID" required>
                        </div>
                        <div class="col-lg-6">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Email Address" required>
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="name" id="name" class="form-control" placeholder="Name" required>
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="surname" id="surname" class="form-control" placeholder="Surname" required>
                        </div>
                        <div class="col-lg-6">
                            <select class="form-control" name="level" id="level" placeholder="Level" required>
                                <option value="null">Level</option>
                                <option value="part 2">Part 2</option>
                                <option value="part 3">Part 3</option>
                                <option value="part 4">Part 4</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <input type="number" class="form-control" name="year" id="year" placeholder="Year"  min="2005" max="2099" required>
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="supervisor" id="supervisor" class="form-control" placeholder="supervisor (surname first)" required>
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="department" id="department" class="form-control" placeholder="Department" required>
                        </div>
                        
                        <div class="col-lg-6">
                            <input type="text" name="school" id="school" class="form-control" placeholder="School" required>
                        </div>
                        <div class="col-lg-12">
                            <input type="text" name="title" id="title" class="form-control" placeholder="Title" required>
                        </div>
                        <div class="col-lg-12">
                            <textarea class="form-control p-2" name="abstract" id="abstract" placeholder="Describe your project in 800 characters or less..." required style="height: 150px;"></textarea>
                        </div>
                        <div class="col-lg-12">
                            <input type="text" name="tags" id="tags" class="form-control" placeholder="Enter 5 keywords that describes your project" required>
                        </div>
                        </br></br>
                        <div class="col-lg-12">
                            <input type="file" id="myFile">
                                <script>
                                    function myFunction() {
                                        var x = document.getElementById("myFile");
                                        x.disabled = true;
                                    }
                                    </script>
                        </div>
                        </br></br></br>
                        <div class="col-lg-12">
                            <button class="btn btn-primary" type="submit" value="send">Submit Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo file_get_contents("footer.html"); ?>