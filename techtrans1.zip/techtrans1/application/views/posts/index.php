

<!DOCTYPE html>

<!-- /navigation --> 

<section class="page-title overlay" style="background-image: url(assets/images/background/page-title.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="text-white font-weight-bold">TTLCC News & Events</h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="home">Home</a>
                    </li>
                    <li>TTLCC News & Events</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- blog -->
<section class="section">
    <div class="container">
        
        <div class="row">
            <!-- blog-item -->
            <div class="col-lg4-4 col-sm-6 mb-4">
                <?php foreach($posts as $post) : ?>
                <div class="card">
                    <div class="card-img-wrapper overlay-rounded-top">
                        <img class="card-img-top" src="<?php echo site_url();?>assets/images/blog/blog-1.jpg" alt="blog-thumbnail">
                    </div>
                    <div class="card-body p-0">
                        <div class="d-flex">
                            <div class="py-3 px-4 border-right text-center">
                                <h3 class="text-primary mb-0">25</h3>
                                <p class="mb-0">Nov</p>
                            </div>
                            <div class="p-3">
                                <a href="<?php echo site_url('/posts/'.$post['slug']);?>" class="h4 font-primary text-dark"><?php echo $post['title'];?></a>
                                
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
            </div>  
        </div>
    </div>
</section>
<!-- /blog -->
