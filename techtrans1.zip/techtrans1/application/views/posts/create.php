
<!DOCTYPE HTML>
        <!-- TinyMCE script -->
        
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<h2 class="title1"><?= $title; ?></h2>
				<div class="blank-page widget-shadow scroll" id="style-2 div1">
                <div class="p-5 rounded box-shadow">
                    <?php echo validation_errors(); ?>
                    <?php echo form_open('posts/create'); ?>
                        <div class="col-lg-12">
                            <input type="text" name="title" id="title" class="form-control" placeholder="Enter post title">
                        </div>
                        </br></br>
                        <div class="col-lg-6">
                            <input type="text" class="form-control" name="author" id="author" placeholder="Author">
                        </div>
                        </br></br>
                        <div class="col-lg-12">
                        <input type="file" name="post_image" id="post_image" value="upload">
                        </div>
                        </br></br>
                        <div class="col-lg-12">
                        <!-- Textarea -->
                        <textarea class='editor' name='content'>
                        <?php if(isset($content)){ echo $content; } ?> 
                        </textarea>
                        </div>
                        </br></br>
                        <div class="col-lg-12">
                            <input type="text" name="tags" id="tags" class="form-control" placeholder="Enter 5 keywords that describes the post">
                        </div>
                                            
                        <div class="col-lg-12">
                            <button class="btn btn-primary" type="submit" value="send">Submit Now</button>
                        </div>
                    </form>
                </div>
			</div>
		</div>
        <!-- Script -->
        <script>
        tinymce.init({ 
        selector:'.editor',
        theme: 'modern',
        height: 200
        });
        </script>
            