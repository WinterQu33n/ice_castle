<?php
class Startup extends CI_Controller{

	public function index(){	
        
        $data['startups'] = $this->startup_model->get_startup();
 
        $this->load->view('templates/header');
        $this->load->view('startups_view', $data);
        $this->load->view('templates/footer');
        }
        
        public function view($product = NULL ){
                $data['startup'] = $this->startup_model->get_startup($product);

                if(empty($data['startup'])){
                        show_404();
                }

                $data['product'] = $data['startup']['product'];

                        $this->load->view('templates/admin_header');
                        $this->load->view('startup', $data);
                        $this->load->view('templates/admin_footer'); 
        }

        public function create(){
                $data['title'] = 'Enter StartUp';
                
                $this->form_validation->set_rules('co_name' , 'Co_name', 'required');
                $this->form_validation->set_rules('product' , 'Product', 'required');
                $this->form_validation->set_rules('category' , 'category', 'required');
                $this->form_validation->set_rules('expertise' , 'Expertise', 'required');
                $this->form_validation->set_rules('date_joined' , 'Date_Joined', 'required');
                $this->form_validation->set_rules('product' , 'Product', 'required');
                $this->form_validation->set_rules('about' , 'About', 'required');

                
                if($this->form_validation->run() === FALSE){
                        $this->load->view('templates/admin_header');
                        $this->load->view('admin/enter_startup', $data);
                        $this->load->view('templates/admin_footer');   
                } else {
                        $this->startup_model->create_startup();
                        redirect('enter_startup');
                }
                
        }
	
}
